import BackgroundWave from "./BackgroundWave";

export { BackgroundWave };
