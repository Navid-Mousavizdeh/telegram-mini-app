import WaveLayout from "./WaveLayout";

export { WaveLayout };
