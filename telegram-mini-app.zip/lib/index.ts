import { database } from "./database";

export { database };
