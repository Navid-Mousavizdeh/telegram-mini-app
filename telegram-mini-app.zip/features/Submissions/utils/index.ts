import { getCategoryChip } from "./getCategoryChip";

export { getCategoryChip };
