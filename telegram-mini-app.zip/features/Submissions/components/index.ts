import { SubmissionTable } from "./SubmissionTable";
import { SubmissionCard } from "./SubmissionCard";

export { SubmissionTable, SubmissionCard };
