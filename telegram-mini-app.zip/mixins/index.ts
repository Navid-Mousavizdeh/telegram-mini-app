import { fadeInSlideUp, slideUp } from "./fadeInSlideUp";

export { fadeInSlideUp, slideUp };
