"use client";

import Submissions from "@/features/Submissions";

export default function SubmissionsPage() {
  return <Submissions />;
}
