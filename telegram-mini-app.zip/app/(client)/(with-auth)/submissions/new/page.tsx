"use client";

import NewSubmission from "@/features/NewSubmission";

export default function NewSubmissionPage() {
  return <NewSubmission />;
}
