"use client";

import Login from "@/features/authentication/Login";

export default function LoginPage() {
  return <Login />;
}
