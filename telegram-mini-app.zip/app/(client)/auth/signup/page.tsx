"use client";

import SignUp from "@/features/authentication/Signup";

export default function SignUpPage() {
  return <SignUp />;
}
